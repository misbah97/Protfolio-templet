$(document).ready(function(){
    $('body').materialScrollTop();
    new WOW().init();
    $('.counter').counterUp({
        delay: 10,
        time: 2000,
    });
    $('html').smoothScroll(2000);
});